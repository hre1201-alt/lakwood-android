package ir.lakwood.store

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var searchInput: EditText

    private val site = "https://lakwood.ir"
    private val ink = Color.rgb(36, 44, 39)
    private val accent = Color.rgb(48, 105, 78)
    private val paper = Color.rgb(250, 249, 246)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ink
        window.navigationBarColor = ink
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildUi()

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return routeUrl(request.url.toString())
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                progress.progress = newProgress
            }
        }
        if (savedInstanceState == null) {
            webView.loadUrl("$site/")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(paper)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(ink)
        }
        val title = TextView(this).apply {
            text = "لاک‌وود"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "فروشگاه اینترنتی"
            textSize = 12f
            setTextColor(Color.rgb(220, 229, 221))
            gravity = Gravity.CENTER
        }
        header.addView(title)
        header.addView(subtitle)

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        searchInput = EditText(this).apply {
            hint = "جست‌وجوی محصولات…"
            textSize = 14f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(12), 0, dp(12), 0)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.rgb(245, 245, 242))
        }
        val searchButton = Button(this).apply {
            text = "جست‌وجو"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
            setOnClickListener { searchProducts() }
        }
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                searchProducts()
                true
            } else false
        }
        searchRow.addView(searchInput, LinearLayout.LayoutParams(0, dp(46), 1f))
        searchRow.addView(searchButton, LinearLayout.LayoutParams(dp(100), dp(46)))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            visibility = View.GONE
        }

        webView = WebView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setBackgroundColor(Color.WHITE)
        }

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
        }
        addNav(nav, "خانه", "$site/")
        addNav(nav, "محصولات", "$site/shop/")
        addNav(nav, "دسته‌ها", "$site/product-category/")
        addNav(nav, "سبد خرید", "$site/cart/")
        addNav(nav, "حساب من", "$site/my-account/")

        root.addView(header)
        root.addView(searchRow)
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)))
        setContentView(root)
    }

    private fun addNav(parent: LinearLayout, label: String, url: String) {
        val button = TextView(this).apply {
            text = label
            textSize = 11f
            setTextColor(ink)
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(8), dp(2), dp(8))
            isClickable = true
            isFocusable = true
            setOnClickListener { webView.loadUrl(url) }
        }
        parent.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
    }

    private fun searchProducts() {
        val query = searchInput.text.toString().trim()
        if (query.isEmpty()) {
            Toast.makeText(this, "نام محصول را وارد کنید", Toast.LENGTH_SHORT).show()
            return
        }
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        val url = Uri.parse("$site/").buildUpon()
            .appendQueryParameter("s", query)
            .appendQueryParameter("post_type", "product")
            .build()
            .toString()
        webView.loadUrl(url)
    }

    private fun routeUrl(raw: String): Boolean {
        val uri = Uri.parse(raw)
        val scheme = uri.scheme.orEmpty()
        if (scheme == "http" || scheme == "https") {
            // Keep store and payment-provider pages in the same WebView so checkout/session cookies survive.
            return false
        }
        if (scheme == "tel" || scheme == "mailto" || scheme == "sms" || scheme == "intent") {
            try {
                val intent = if (scheme == "intent") {
                    Intent.parseUri(raw, Intent.URI_INTENT_SCHEME)
                } else {
                    Intent(Intent.ACTION_VIEW, uri)
                }
                startActivity(intent)
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "برنامه‌ای برای باز کردن این پیوند پیدا نشد", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, "امکان باز کردن این پیوند وجود ندارد", Toast.LENGTH_SHORT).show()
            }
            return true
        }
        return true
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
